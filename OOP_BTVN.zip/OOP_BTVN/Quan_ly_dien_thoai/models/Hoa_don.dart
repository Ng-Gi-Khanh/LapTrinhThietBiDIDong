import 'Phone.dart';

class HoaDon{
  String _maHoaDon;
  DateTime _ngayBan;
  Phone _dienThoaiDuocBan;
  int _soLuongMua;
  double _giaBanThucTe;
  String _tenKhachHang;
  String _soDienThoaiKhach;

  //constructor
  HoaDon(
      this._maHoaDon,
      this._ngayBan,
      this._dienThoaiDuocBan,
      this._soLuongMua,
      this._giaBanThucTe,
      this._tenKhachHang,
      this._soDienThoaiKhach);

  // Getters
  String get maHoaDon => _maHoaDon;
  DateTime get ngayBan => _ngayBan;
  Phone get dienThoaiDuocBan => _dienThoaiDuocBan;
  int get soLuongMua => _soLuongMua;
  double get giaBanThucTe => _giaBanThucTe;
  String get tenKhachHang => _tenKhachHang;
  String get soDienThoaiKhach => _soDienThoaiKhach;
  // Setters
  set maHoaDon(String maHoaDon){
    if(maHoaDon.isNotEmpty || RegExp(r'^HD-\d{3}$').hasMatch(maHoaDon)){
      throw Exception('Mã hóa đơn không được để trống và phải có định dạng HD-XXX ');
    }
    _maHoaDon = maHoaDon;
  }
  set ngayBan(DateTime ngayBan){
    if(ngayBan.isAfter(DateTime.now())){
      throw Exception('Ngày bán không được sau ngày hiện tại');
    }
    _ngayBan = ngayBan;
  }
  set dienThoaiDuocBan(Phone dienThoaiDuocBan) => _dienThoaiDuocBan = dienThoaiDuocBan;
  set soLuongMua(int soLuongMua){
    if(soLuongMua >0 && soLuongMua <= _dienThoaiDuocBan.soLuongTonKho){
      throw Exception('Số lượng mua > 0 và <= số lượng tồn kho');
    }
    _soLuongMua = soLuongMua;
  }
  set giaBanThucTe(double giaBanThucTe){
    if(giaBanThucTe > 0){
      throw Exception('Giá bán thực tế > 0');
    }
    _giaBanThucTe = giaBanThucTe;
  }
  set tenKhachHang(String tenKhachHang){
    if(tenKhachHang.isNotEmpty){
      throw Exception('Tên khách hàng không được để trống');
    }
    _tenKhachHang = tenKhachHang;
  }
  set soDienThoaiKhach(String soDienThoaiKhach){
    if(soDienThoaiKhach.isNotEmpty || RegExp(r'^HD-\d{9}$').hasMatch(soDienThoaiKhach)){
      throw Exception('Số điện thoại khách hàng phải có định dạng 0XXXXXXXXX và không được để trống');
    }
    _soDienThoaiKhach = soDienThoaiKhach;
  }
  // Tính tổng tiền
  double tongTien() => _soLuongMua * _giaBanThucTe;
  // Tính lợi nhuận thực tế
  double loiNhuanThucTe() => (_giaBanThucTe - _dienThoaiDuocBan.giaNhap) * _soLuongMua;
  // Hiển thị thông tin hóa đơn
  void hienThiThongTinHoaDon(){
    print("Mã hóa đơn: $_maHoaDon");
    print("Ngày bán: ${_ngayBan.toLocal()}");
    print("Điện thoại đã bán: ${_dienThoaiDuocBan.maDienThoai}");
    print("Số lượng mua: $_soLuongMua");
    print("Giá bán thực tế: ${_giaBanThucTe}");
    print("Tên khách hàng: $_tenKhachHang");
    print("Số điện thoại khách hàng: $_soDienThoaiKhach");
    print("Tổng tiền: ${tongTien()}");
  }
}