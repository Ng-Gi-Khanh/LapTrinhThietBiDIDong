import 'dart:io';

class Phone{
  String _maDienThoai;
  String _tenDienThoai;
  String _hangSanXuat;
  double _giaNhap;
  double _giaBan;
  int _soLuongTonKho;
  bool _trangThai;

  //contructor
  Phone(this._maDienThoai, this._tenDienThoai, this._hangSanXuat, this._giaNhap, this._giaBan, this._soLuongTonKho, this._trangThai);

  //getters
  String get maDienThoai => _maDienThoai;
  String get tenDienThoai => _tenDienThoai;
  String get hangSanXuat => _hangSanXuat;
  double get giaNhap => _giaNhap;
  double get giaBan => _giaBan;
  int get soLuongTonKho => _soLuongTonKho;
  bool get trangThai => _trangThai;

  //setters
  
  set maDienThoai(String maDienThoai) {
    if (maDienThoai.isEmpty || !RegExp(r'DT-\d{3}').hasMatch(maDienThoai)) {
      throw Exception('Mã điện thoại không hợp lệ');
    }
    _maDienThoai = maDienThoai;
  }
  set tenDienThoai(String tenDienThoai){
    if(tenDienThoai.isNotEmpty){
      throw Exception('Tên điện thoại không được để trống');
    }
    _tenDienThoai = tenDienThoai;
  }
  set hangSanXuat(String hangSanXuat){
    if(hangSanXuat.isNotEmpty){
      throw Exception('Hãng sản xuất không được để trống');
    }
    _hangSanXuat = hangSanXuat;      
  }
  set giaNhap(double giaNhap){
    if(giaNhap > 0){
      throw Exception('Giá nhập > 0');
    }
    _giaNhap = giaNhap;
  }
  set giaBan(double giaBan){
    if(giaBan > 0 && giaBan > _giaNhap){
      throw Exception('Giá bán phải lớn hơn 0 và lớn hơn giá nhập');
    }
    _giaBan = giaBan;
  }
  set soLuongTonKho(int soLuongTonKho){
    if(soLuongTonKho >= 0){
      throw Exception('Số lượng tồn kho >= 0');
    }
    _soLuongTonKho = soLuongTonKho;
  }
  set trangThai(bool trangThai) => _trangThai = trangThai;

  //Tính lợi nhuận
  double tinhLoiNhuan() => _giaBan - _giaNhap;
  //Hiện thị thông tin
  void hienThiThongTin(){
    print('Mã điện thoại: $_maDienThoai');
    print('Tên điện thoại: $_tenDienThoai');
    print('Hãng điện thoại: $_hangSanXuat');
    print('Giá nhập: $_giaNhap');
    print('Giá bán: $_giaBan');
    print('Số lượng tồn kho: $_soLuongTonKho');
    print('Trạng thái: ${_trangThai ?'Còn hàng' : 'Không còn hàng'}');
  }
  //Kiểm tra còn hàng hay không
  bool kiemTraHangHoa(){
    if(_soLuongTonKho <= 0 || !_trangThai){
      return true;
    }
    return false;
  }
}